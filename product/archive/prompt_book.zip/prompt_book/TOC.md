---
title: "Prompt Ecosystem Book — Table of Contents"
type: "toc"
tags:
  - "book"
  - "prompt-library"
created: "2026-02-14"
---

# Table of Contents

## Part I — Foundations (House Styles & Doctrine)

- [01. PYTHON HOUSE STYLE](./chapters/01_python_house_style.md)
- [02. RUST HOUSE STYLE](./chapters/02_rust_house_style.md)
- [03. RUST ANTIBLOAT](./chapters/03_rust_antibloat.md)
- [04. COLAB NOTEBOOK HOUSE STYLE](./chapters/04_colab_notebook_house_style.md)

## Part II — Core Discovery & Implementation

- [05. Agent Architect (10-phase agent systems blueprint)](./chapters/05_agent_architect_10_phase_agent_systems_blueprint.md)
- [06. REPO DISCOVERY — Massive Prompt](./chapters/06_repo_discovery_massive_prompt.md)
- [07. PYTHON_prompt — Repo-Discovery Engineer](./chapters/07_python_prompt_repo_discovery_engineer.md)
- [08. RUST_prompt — Repo-Discovery Engineer](./chapters/08_rust_prompt_repo_discovery_engineer.md)
- [09. Terrifyingly Exhaustive Repo Analysis → Service Platform](./chapters/09_terrifyingly_exhaustive_repo_analysis_service_platform.md)

## Part III — Multimodal & Constraint-Matrix Prompts

- [10. Restore Simple — OpenAI](./chapters/10_restore_simple_openai.md)
- [15. Multimodal Restoration Pipeline — Restore Simple × Engineering × Colab](./chapters/15_multimodal_restoration_pipeline_restore_simple_engineering_c.md)

## Part IV — Extreme Combos (Production Platformization)

- [11. OMNI AGENT PLATFORM — Repo → Service → MCP → Agent Ecosystem](./chapters/11_omni_agent_platform_repo_service_mcp_agent_ecosystem.md)
- [12. Evidence-Driven Implementation — Smallest Correct Diff (Python/Rust gated)](./chapters/12_evidence_driven_implementation_smallest_correct_diff_python_.md)
- [13. MCP Server Factory — Tool Suite Design + Implementation](./chapters/13_mcp_server_factory_tool_suite_design_implementation.md)
- [14. Prompt Library Composer — Component Extraction + Synthesis](./chapters/14_prompt_library_composer_component_extraction_synthesis.md)
- [16. Service Industrializer — Exhaustive but Disciplined](./chapters/16_service_industrializer_exhaustive_but_disciplined.md)

## Part V — Reliability, Ops, Security

- [17. Agent Testing & Eval Gauntlet](./chapters/17_agent_testing_eval_gauntlet.md)
- [18. Security Threat Model — STRIDE/LINDDUN + Mitigations + Verification](./chapters/18_security_threat_model_stride_linddun_mitigations_verificatio.md)
- [19. Migration & Rollout — Compatibility, Canary, Rollback](./chapters/19_migration_rollout_compatibility_canary_rollback.md)
- [20. Incident Response + Postmortem](./chapters/20_incident_response_postmortem.md)

## Part VI — Orchestration Layer (Chaining Prompts)

- [21. Chain Router + Runbook](./chapters/21_chain_router_runbook.md)
- [22. Handoff Packet Generator](./chapters/22_handoff_packet_generator.md)
- [23. Chain Execution Protocol](./chapters/23_chain_execution_protocol.md)
