---
title: "Prompt Ecosystem Book — README"
type: "readme"
tags:
  - "prompt-library"
  - "book"
  - "ontology"
created: "2026-02-14"
---

# Prompt Ecosystem Book

This directory is a **compiled “book edition”** of the prompt ecosystem in this repo.

Start here:

- **Book (main)**: [`BOOK.md`](./BOOK.md)
- **Ontology**: [`ONTOLOGY.md`](./ONTOLOGY.md)
- **Catalog (table form)**: [`CATALOG.md`](./CATALOG.md)

The book is generated from the canonical prompt files in the repo.

To (re)build the book:

```cmd
python prompt_book\_build_book.py
```

This will regenerate:

- `prompt_book/BOOK.md`
- `prompt_book/TOC.md`
- `prompt_book/ONTOLOGY.md`
- `prompt_book/CATALOG.md`
- `prompt_book/chapters/*.md`
- `prompt_book/ontology/*`
