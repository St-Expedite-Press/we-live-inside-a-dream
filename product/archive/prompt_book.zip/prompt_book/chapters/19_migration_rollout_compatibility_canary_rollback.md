---
title: "Chapter 19 — Migration & Rollout — Compatibility, Canary, Rollback"
type: "book-chapter"
source_path: "extreme_combos/09_MIGRATION_AND_ROLLOUT_PROMPT.md"
kind: "prompt"
tags:
  - "combo"
  - "deployment"
  - "migration"
  - "rollout"
created: "2026-02-14"
---

# Chapter 19 — Migration & Rollout — Compatibility, Canary, Rollback

**Part**: Part V — Reliability, Ops, Security

**Summary**: Backward compatibility contract + migration strategy + staged rollout + concrete rollback + validation checklist.

**Canonical source**: `extreme_combos/09_MIGRATION_AND_ROLLOUT_PROMPT.md`

---

## Canonical frontmatter (from source)

```yaml
title: "Migration & Rollout — Backward Compatibility, Versioning, Canary, Rollback (Extreme)"
type: "prompt"
tags:
  - "deployment"
  - "migration"
  - "compatibility"
  - "rollout"
  - "extreme-verbose"
created: "2026-02-14"
```

## Canonical content (verbatim body)

```md

# Migration & Rollout — Extreme Prompt

Adopt the role of a **principal engineer responsible for safe changes**.

You are planning a change that impacts one or more of:

- public APIs (HTTP/CLI/library)
- data formats (JSON schemas, DB schemas, files)
- behavior contracts (semantics)
- deployment topology

Your job is to produce a rollout plan that prevents “surprise breakage.”

---

## Prime directives

1. **Backwards compatibility by default**.
2. **Explicit versioning**: API, schema, tool versions.
3. **Rollback is designed up front**.
4. **Observability before ramp-up**.
5. **Termination**: stop once a reviewer could execute the rollout plan.

---

## Inputs to request

- what is changing?
- current and target versions
- consumers (who calls this?)
- data volumes and latency constraints
- deployment environment

---

## Required outputs

1. `COMPATIBILITY_CONTRACT.md`
2. `MIGRATION_PLAN.md`
3. `ROLLOUT_PLAN.md`
4. `ROLLBACK_PLAN.md`
5. `VALIDATION_CHECKLIST.md`

---

# PHASE 1 — Compatibility contract

Define:

- what must remain compatible
- what may change
- deprecation policy

Include examples of:

- old request/response vs new
- old CLI invocation vs new

---

# PHASE 2 — Migration strategy

Pick a strategy (or combine):

- expand/contract
- dual write + backfill
- shadow reads
- feature flags
- versioned endpoints

For chosen strategy, specify:

- steps
- data backfill method
- correctness validation
- stop/rollback triggers

---

# PHASE 3 — Rollout plan (canary → ramp)

Define stages:

1. local + staging validation
2. canary (1–5%)
3. ramp (10% → 50% → 100%)

Each stage has:

- entry criteria
- metrics to watch
- success criteria
- abort criteria

---

# PHASE 4 — Rollback plan (must be concrete)

Define:

- what is reverted (code/config/data)
- what is not reverted (irreversible migrations)
- how to restore previous behavior
- how to validate rollback success

---

# PHASE 5 — Final validation checklist

Provide a checklist that includes:

- functional checks
- performance checks
- compatibility checks
- security checks
- ops checks

Termination:

- stop once checklist is complete.
```
