---
title: "Prompt Ecosystem Book — Catalog"
type: "catalog"
tags:
  - "book"
  - "prompt-library"
created: "2026-02-14"
---

# Catalog

This is a table-form index of all artifacts included in the book.

| # | Title | Kind | Part | Source | Chapter | Tags |
|---:|---|---|---|---|---|---|
| 01 | PYTHON HOUSE STYLE | guidelines | Part I — Foundations (House Styles & Doctrine) | `PYTHON HOUSE STYLE.md` | [01](./chapters/01_python_house_style.md) | python, guidelines, house-style |
| 02 | RUST HOUSE STYLE | guidelines | Part I — Foundations (House Styles & Doctrine) | `RUST HOUSE STYLE.md` | [02](./chapters/02_rust_house_style.md) | rust, guidelines, house-style |
| 03 | RUST ANTIBLOAT | guidelines | Part I — Foundations (House Styles & Doctrine) | `RUST ANTIBLOAT.md` | [03](./chapters/03_rust_antibloat.md) | rust, guidelines, restraint, anti-bloat |
| 04 | COLAB NOTEBOOK HOUSE STYLE | guidelines | Part I — Foundations (House Styles & Doctrine) | `COLAB NOTEBOOK HOUSE STYLE.md` | [04](./chapters/04_colab_notebook_house_style.md) | python, notebooks, guidelines, reproducibility |
| 05 | Agent Architect (10-phase agent systems blueprint) | prompt | Part II — Core Discovery & Implementation | `massiveprompt.md` | [05](./chapters/05_agent_architect_10_phase_agent_systems_blueprint.md) | agent-systems, architecture, phases |
| 06 | REPO DISCOVERY — Massive Prompt | prompt | Part II — Core Discovery & Implementation | `REPO_DISCOVERY_prompt.md` | [06](./chapters/06_repo_discovery_massive_prompt.md) | repo-analysis, architecture, diff-discipline |
| 07 | PYTHON_prompt — Repo-Discovery Engineer | prompt | Part II — Core Discovery & Implementation | `PYTHON_prompt.md` | [07](./chapters/07_python_prompt_repo_discovery_engineer.md) | python, repo-analysis, implementation |
| 08 | RUST_prompt — Repo-Discovery Engineer | prompt | Part II — Core Discovery & Implementation | `RUST_prompt.md` | [08](./chapters/08_rust_prompt_repo_discovery_engineer.md) | rust, repo-analysis, implementation |
| 09 | Terrifyingly Exhaustive Repo Analysis → Service Platform | prompt | Part II — Core Discovery & Implementation | `Explore Repo.md` | [09](./chapters/09_terrifyingly_exhaustive_repo_analysis_service_platform.md) | repo-analysis, service-transformation, mcp, knowledge-graph |
| 10 | Restore Simple — OpenAI | prompt | Part III — Multimodal & Constraint-Matrix Prompts | `Restore Simple-- OpenAI.md` | [10](./chapters/10_restore_simple_openai.md) | image-restoration, multimodal, constraints |
| 11 | OMNI AGENT PLATFORM — Repo → Service → MCP → Agent Ecosystem | prompt | Part IV — Extreme Combos (Production Platformization) | `extreme_combos/01_OMNI_AGENT_PLATFORM_PROMPT.md` | [11](./chapters/11_omni_agent_platform_repo_service_mcp_agent_ecosystem.md) | combo, repo-analysis, mcp, agent-systems, knowledge-graph |
| 12 | Evidence-Driven Implementation — Smallest Correct Diff (Python/Rust gated) | prompt | Part IV — Extreme Combos (Production Platformization) | `extreme_combos/02_EVIDENCE_DRIVEN_IMPLEMENTATION_PROMPT.md` | [12](./chapters/12_evidence_driven_implementation_smallest_correct_diff_python_.md) | combo, implementation, diff-discipline |
| 13 | MCP Server Factory — Tool Suite Design + Implementation | prompt | Part IV — Extreme Combos (Production Platformization) | `extreme_combos/03_MCP_SERVER_FACTORY_PROMPT.md` | [13](./chapters/13_mcp_server_factory_tool_suite_design_implementation.md) | combo, mcp, tooling, security, testing |
| 14 | Prompt Library Composer — Component Extraction + Synthesis | prompt | Part IV — Extreme Combos (Production Platformization) | `extreme_combos/04_PROMPT_LIBRARY_COMPOSER_PROMPT.md` | [14](./chapters/14_prompt_library_composer_component_extraction_synthesis.md) | combo, meta, prompt-engineering |
| 15 | Multimodal Restoration Pipeline — Restore Simple × Engineering × Colab | prompt | Part III — Multimodal & Constraint-Matrix Prompts | `extreme_combos/05_MULTIMODAL_RESTORATION_PIPELINE_PROMPT.md` | [15](./chapters/15_multimodal_restoration_pipeline_restore_simple_engineering_c.md) | combo, multimodal, pipelines, colab |
| 16 | Service Industrializer — Exhaustive but Disciplined | prompt | Part IV — Extreme Combos (Production Platformization) | `extreme_combos/06_SERVICE_INDUSTRIALIZER_PROMPT.md` | [16](./chapters/16_service_industrializer_exhaustive_but_disciplined.md) | combo, service-transformation, restraint |
| 17 | Agent Testing & Eval Gauntlet | prompt | Part V — Reliability, Ops, Security | `extreme_combos/07_AGENT_TESTING_AND_EVAL_GAUNTLET_PROMPT.md` | [17](./chapters/17_agent_testing_eval_gauntlet.md) | combo, agent-systems, testing, observability |
| 18 | Security Threat Model — STRIDE/LINDDUN + Mitigations + Verification | prompt | Part V — Reliability, Ops, Security | `extreme_combos/08_SECURITY_THREAT_MODEL_PROMPT.md` | [18](./chapters/18_security_threat_model_stride_linddun_mitigations_verificatio.md) | combo, security, threat-model |
| 19 | Migration & Rollout — Compatibility, Canary, Rollback | prompt | Part V — Reliability, Ops, Security | `extreme_combos/09_MIGRATION_AND_ROLLOUT_PROMPT.md` | [19](./chapters/19_migration_rollout_compatibility_canary_rollback.md) | combo, deployment, migration, rollout |
| 20 | Incident Response + Postmortem | prompt | Part V — Reliability, Ops, Security | `extreme_combos/10_INCIDENT_RESPONSE_AND_POSTMORTEM_PROMPT.md` | [20](./chapters/20_incident_response_postmortem.md) | combo, ops, incident-response, postmortem |
| 21 | Chain Router + Runbook | prompt | Part VI — Orchestration Layer (Chaining Prompts) | `extreme_combos/11_CHAIN_ROUTER_AND_RUNBOOK_PROMPT.md` | [21](./chapters/21_chain_router_runbook.md) | combo, orchestration, router |
| 22 | Handoff Packet Generator | prompt | Part VI — Orchestration Layer (Chaining Prompts) | `extreme_combos/12_HANDOFF_PACKET_GENERATOR_PROMPT.md` | [22](./chapters/22_handoff_packet_generator.md) | combo, orchestration, handoff |
| 23 | Chain Execution Protocol | prompt | Part VI — Orchestration Layer (Chaining Prompts) | `extreme_combos/13_CHAIN_EXECUTION_PROTOCOL_PROMPT.md` | [23](./chapters/23_chain_execution_protocol.md) | combo, orchestration, protocol, governance |

## Notes

- **Source** points at the canonical file in the repo.
- **Chapter** is the compiled book rendition of the artifact.