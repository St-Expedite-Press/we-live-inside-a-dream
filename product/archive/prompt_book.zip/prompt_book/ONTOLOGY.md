---
title: "Prompt Ecosystem Ontology"
type: "ontology"
tags:
  - "ontology"
  - "prompt-library"
created: "2026-02-14"
---

# Prompt Ecosystem Ontology

This ontology models the library as a **directed ecosystem**:

- artifacts (prompts/guidelines/indexes)
- domains (what the artifact is about)
- techniques (what the artifact *does*)
- relationships (how artifacts compose into chains)

The goal is not academic purity; it’s practical routing: **given an objective, pick the right prompt(s) and order them safely**.

---

## 1) Core entity types

### 1.1 Artifact
An **Artifact** is any first-class Markdown object in the library:

- prompts (procedural, phased, actionable)
- guidelines (constraints/standards)
- indexes/readmes (navigation)
- intermediate orchestrators (routers/handoffs/protocols)

Minimum fields:

- `id`: stable identifier (e.g. `EC-03`)
- `title`: human label
- `kind`: prompt | guidelines | index
- `domain_tags`: e.g. `repo-analysis`, `mcp`, `security`
- `techniques`: e.g. `phases`, `evidence-ledger`, `schema-first`
- `inputs`: what it requires to run
- `outputs`: deliverables it promises

### 1.2 Domain
A **Domain** is a topical cluster:

- `repo-analysis` / `implementation`
- `agent-systems`
- `mcp` / `tooling`
- `knowledge-graph`
- `multimodal` / `image-restoration`
- `security`
- `ops` / `observability`
- `meta-orchestration`

### 1.3 Technique
A **Technique** is a reusable behavioral primitive (components you can compose):

- phased workflow
- evidence → hypothesis → next-actions loop
- constraint matrices
- schema-first tool design
- termination gates / stop conditions
- abstraction budgets (anti-bloat)
- safety/approval gates (mutations)
- regression/eval harness design

### 1.4 Relationship
Relationships are edges between artifacts:

- `COMBINES_WITH` (A is a combo of B+C)
- `ENFORCES` (A enforces guideline G)
- `ROUTES_TO` (A selects and dispatches to B)
- `PRECEDES` (A should run before B)
- `PRODUCES_INPUT_FOR` (A outputs data B requires)

---

## 2) Canonical ecosystem graph (high-level)

```mermaid
graph TD
  HS[House Styles & Discipline] --> IMPL[Evidence-Driven Implementation]
  HS --> SRV[Service Industrializer / Omni Platform]
  IMPL --> ROL[Migration & Rollout]
  SRV --> MCP[MCP Server Factory]
  MCP --> EVAL[Agent Testing & Eval]
  SRV --> SEC[Security Threat Model]
  SEC --> IMPL
  ROL --> OPS[Incident Response & Postmortem]
  ROUTER[Chain Router + Runbook] --> IMPL
  ROUTER --> SRV
  ROUTER --> MCP
  ROUTER --> SEC
  ROUTER --> ROL
  ROUTER --> EVAL
  HANDOFF[Handoff Packet Generator] --> ROUTER
  PROTO[Chain Execution Protocol] --> ROUTER
```

Interpretation:

- **House styles** constrain implementation prompts.
- **Security** often precedes implementation for high-risk objectives.
- **Rollout** precedes production deploy.
- **Incident response** is an interrupt handler: it can preempt the chain.

---

## 3) Artifact IDs included in this book

- `F-01` → `PYTHON HOUSE STYLE.md`
- `F-02` → `RUST HOUSE STYLE.md`
- `F-03` → `RUST ANTIBLOAT.md`
- `F-04` → `COLAB NOTEBOOK HOUSE STYLE.md`
- `C-01` → `massiveprompt.md`
- `C-02` → `REPO_DISCOVERY_prompt.md`
- `C-03` → `PYTHON_prompt.md`
- `C-04` → `RUST_prompt.md`
- `C-05` → `Explore Repo.md`
- `M-01` → `Restore Simple-- OpenAI.md`
- `EC-01` → `extreme_combos/01_OMNI_AGENT_PLATFORM_PROMPT.md`
- `EC-02` → `extreme_combos/02_EVIDENCE_DRIVEN_IMPLEMENTATION_PROMPT.md`
- `EC-03` → `extreme_combos/03_MCP_SERVER_FACTORY_PROMPT.md`
- `EC-04` → `extreme_combos/04_PROMPT_LIBRARY_COMPOSER_PROMPT.md`
- `EC-05` → `extreme_combos/05_MULTIMODAL_RESTORATION_PIPELINE_PROMPT.md`
- `EC-06` → `extreme_combos/06_SERVICE_INDUSTRIALIZER_PROMPT.md`
- `EC-07` → `extreme_combos/07_AGENT_TESTING_AND_EVAL_GAUNTLET_PROMPT.md`
- `EC-08` → `extreme_combos/08_SECURITY_THREAT_MODEL_PROMPT.md`
- `EC-09` → `extreme_combos/09_MIGRATION_AND_ROLLOUT_PROMPT.md`
- `EC-10` → `extreme_combos/10_INCIDENT_RESPONSE_AND_POSTMORTEM_PROMPT.md`
- `EC-11` → `extreme_combos/11_CHAIN_ROUTER_AND_RUNBOOK_PROMPT.md`
- `EC-12` → `extreme_combos/12_HANDOFF_PACKET_GENERATOR_PROMPT.md`
- `EC-13` → `extreme_combos/13_CHAIN_EXECUTION_PROTOCOL_PROMPT.md`

---

## 4) Prompt selection heuristics (routing rules)

Use these rules when deciding what to run:

1. If there is an active outage or customer incident → run **Incident Response** first.
2. If the objective is a small feature/bugfix → run **Evidence-Driven Implementation**.
3. If the objective is ‘turn repo into a service/tool platform’ → run **Omni Agent Platform** or **Service Industrializer**.
4. If you are exposing capabilities to agents → run **MCP Server Factory**.
5. If anything touches prod → run **Migration & Rollout**.
6. If agents/tools must be reliable → run **Agent Testing & Eval Gauntlet**.

---

## 5) Ontology exports

See `prompt_book/ontology/` for machine-readable exports:

- `prompt_ecosystem.json`
- `prompt_ecosystem.jsonld`
- `prompt_ecosystem.yaml`
